//
//  main.m
//  PerformanceMonitor
//
//  Created by tanhao on 15/11/13.
//  Copyright © 2015年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
