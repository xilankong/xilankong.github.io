//
//  AppDelegate.h
//  PerformanceMonitor
//
//  Created by tanhao on 15/11/13.
//  Copyright © 2015年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

